---
label: Miscellaneous
order: 90
icon: kebab-horizontal
---
## Terms

**Repository**: Contains all the extensions/sites.

**Extension/Source/Site**: Contains all the videos/servers of a site.

**Server**: Hosts the videos.


## Installing Sorastream

[!embed](https://www.youtube-nocookie.com/embed/yDuXGAnFQuI)

!!!For Sorastream related FAQ, click [!badge variant="secondary" text="here"](/troubleshooting.md/#sorastream)
!!!
