---
label: Recommended Sources
icon: star
order: 999
---

## English

### Movies & TV Series
1. Sorastream `Hexated`
2. Superstream `English`
3. Sflix bundle `English`
4. AllMoviesForYou `English`

### Anime
1. Kickassanime `Hexated`
2. KronchEN `Crunchyroll`
3. Zoro `English`
4. 9anime `Storm`
5. Allanime `English`
6. Sorastream `Hexated`
7. Yugenanime `Hexated`
8. Animension `Storm`
9. Gogo `English`

### Asian Contents
1. Sorastream `Hexated`
2. Kisskh `Hexated` 
3. Kissasian `Hexated`
4. Dramacool `Horis`
5. Sflix bundle `English`
6. ShowFlix `Indian languages`

### Livestreams
1. IPTV-org (TV) `Multilingual`
2. Time4TV (Sports) `Hexated`
3. TV247 `Hexated`
4. 123TV `Hexated`
5. Crichd `Darkdemon`
