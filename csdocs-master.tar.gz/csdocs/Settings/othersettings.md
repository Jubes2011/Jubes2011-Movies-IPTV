---
label: Other Settings
order: 800
icon: kebab-horizontal
---

## Sub/Dub Filter for Anime

[!badge variant="dark" icon="/static/base.png" text="Cloudstream"] → [!badge variant="dark" icon="/static/gear.png" text="Settings"] → [!badge variant="dark"  text="Providers"] → [!badge variant="dark"  text="Display Dubbed/Subbed Anime"] and apply your wanted filter.

## NSFW

[!embed](https://www.youtube-nocookie.com/embed/5wT6gGezQxI)
